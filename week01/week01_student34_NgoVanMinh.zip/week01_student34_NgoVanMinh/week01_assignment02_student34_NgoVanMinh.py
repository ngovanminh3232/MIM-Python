# %% [markdown]
# ####  a, VS Code là một phần mềm mã nguồn mở. Bởi vì Vs code hỗ trợ một môi trường dễ dàng tích hợp các plugin cho các nhà phát triển hoặc bên thứ ba
# #### b, Notepad, Sublime Text , Vim.
# #### c, Visual Studio Code là một phần mềm phát triển tích hợp hay viết tắt là IDE (do tên dễ gây nhầm lần với Vs Code)


