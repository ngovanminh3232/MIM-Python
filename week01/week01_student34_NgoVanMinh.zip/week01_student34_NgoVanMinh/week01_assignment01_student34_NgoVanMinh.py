# %% [markdown]
# #### a, Python ra mắt vào đầu năm 1991 do  Guido van Rossum một nhà phát triển phát triển phần mềm Hà Lan tạo ra
# #### b, Cái tên do Rossum lấy cảm hứng từ nhóm hài Monty Python
# #### c, Tính tới thời điểm 13/7/2022 thì phiên bản mới nhất của python là 3.10.5


