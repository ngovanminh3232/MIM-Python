# %% [markdown]
# ##### a, Công cụ pip dùng quản lý thư viện của Python cho phép cài dặt hay cập nhật hay gỡ cài đặt các các gói PyPI
# ##### b, pip freeze xuất ra các gói đã cài đặt theo danh sách không phân biệt chữ hoa chữ thường
# ##### c, Một công cụ tương tự pip là conda.


