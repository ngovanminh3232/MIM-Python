def square(x):
    return x**2

if __name__ == '__main__':
    print(f"Resul is {square(23)}")     #529
